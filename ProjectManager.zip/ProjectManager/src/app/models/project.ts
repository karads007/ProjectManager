export interface IProject {
    Id: number;
    Name: string;
    StartDate: string;  
    EndDate: string;
    Priority: string;
    ManagerId: number;
    ManagerName: string;
}