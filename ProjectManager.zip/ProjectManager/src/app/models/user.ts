export interface IUser {
    Id: number;
    FirstName: string;
    LastName: string;
    EmployeeId: number;
}