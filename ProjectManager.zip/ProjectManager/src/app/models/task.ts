export interface ITask {
    Id: number;
    Name: string;
    Priority: number;
    ParentTaskId: number;
    ParentTask: string;
    StartDate: string;  
    EndDate: string; 
    ProjectId: number;
    ProjectName: string;
    UserId: number;  
    UserName: string;
}