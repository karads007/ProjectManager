import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateTaskComponent } from './task/task-create/task-create.component';
import { ViewTaskComponent } from './task/task-view/task-view.component';
import { EditTaskComponent } from './task/task-edit/task-edit.component';
import { UserComponent } from './user/user.component';
import { ProjectComponent } from './project/project.component';

const routes: Routes = [  
  { path:"view-task", component: ViewTaskComponent },
  { path:"edit-task", component: EditTaskComponent },
  { path:"user", component: UserComponent },
  { path:"project", component: ProjectComponent },
  { path:"create-task", component: CreateTaskComponent },
  { path:"**", component: ViewTaskComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
