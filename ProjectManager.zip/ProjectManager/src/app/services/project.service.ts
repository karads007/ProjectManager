import { Injectable } from '@angular/core';
import { IProject } from '../models/project';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private projectsBaseUrl = environment.baseUrl + "projects.json";
  constructor(private http: HttpClient) { }

  getProjects(): Observable<IProject[]> {
    return this.http.get<IProject[]>(this.projectsBaseUrl);
  }

  addProject(project: IProject): Observable<Object> {
    return this.http.post(this.projectsBaseUrl, project);
  }

  updateProject(project: IProject): Observable<Object> {
    return this.http.put(this.projectsBaseUrl, project);
  }

  getProject(id: number): Observable<IProject | undefined> {
    return this.http.get<IProject>(this.projectsBaseUrl + id);
  }
}
