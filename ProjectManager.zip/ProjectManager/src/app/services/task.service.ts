import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ITask } from '../models/task';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private taskUrl = environment.baseUrl + "tasks.json";

  constructor(private http: HttpClient) { }

  getTasks(): Observable<ITask[]> {
    return this.http.get<ITask[]>(this.taskUrl);
  }

  addTask(task: ITask): Observable<Object> {
    return this.http.post(this.taskUrl, task);
  }

  updateTask(task: ITask): Observable<Object> {
    return this.http.put(this.taskUrl, task);
  }

  getTask(id: number): Observable<ITask | undefined> {
    return this.http.get<ITask>(this.taskUrl + id);
  }
}
