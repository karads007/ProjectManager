import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IUser } from '../models/user';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

private usersUrl = environment.baseUrl + "users.json";

  constructor(private http: HttpClient) { }

  getUsers(): Observable<IUser[]> {
    return this.http.get<IUser[]>(this.usersUrl);
  }

  addUser(user: IUser): Observable<Object> {
    return this.http.post(this.usersUrl, user);
  }

  updateUser(user: IUser): Observable<Object> {
    return this.http.put(this.usersUrl, user);
  }

  getUser(id: number): Observable<IUser | undefined> {
    return this.http.get<IUser>(this.usersUrl + id);
  }
}
