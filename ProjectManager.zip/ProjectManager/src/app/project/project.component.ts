import { Component, OnInit } from "@angular/core";
import { ProjectService } from "../services/project.service";
import { IProject } from "../models/project";
import { UserService } from "../services/user.service";
import { IUser } from "../models/user";

@Component({
  selector: "app-project",
  templateUrl: "./project.component.html"
})
export class ProjectComponent implements OnInit {
  project: IProject = {
    Id: 0,
    Name: "",
    StartDate: "",
    EndDate: "",
    Priority: null,
    ManagerId: null,
    ManagerName: ""
  };
  _projectSearchFilter = "";
  _userSearchFilter="";
  filteredProjects: IProject[] = [];
  projects: IProject[] = [];
  users: IUser[] = [];
  filteredUsers: IUser[] = [];

  get projectSearch(): string {
    return this._projectSearchFilter;
  }
  set projectSearch(value: string) {
    this._projectSearchFilter = value;
    this.filteredProjects = this.projectSearch
      ? this.filterProject(this.projectSearch)
      : this.filteredProjects;
  }

  get userSearch(): string {
    return this._userSearchFilter;
  }
  set userSearch(value: string) {
    this._userSearchFilter = value;
    this.filteredUsers = this.userSearch
      ? this.filterUser(this.userSearch)
      : this.filteredUsers;
  }

  constructor(
    private projectService: ProjectService,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.projectService.getProjects().subscribe(proj => {
      this.projects = proj;
      this.filteredProjects = proj;
    });

    this.userService.getUsers().subscribe(usrs => {
      this.users = usrs;
      this.filteredUsers = usrs;
    });
  }

  addProject() {
    this.projectService.addProject(this.project).subscribe(
      result => console.log(result)
    );
  }

  sort(sortby: string) {
    this.filteredProjects = this.filteredProjects.sort((a, b) =>
      a[sortby] > b[sortby] ? 1 : -1
    );
  }

  filterProject(filterBy: string): IProject[] {
    filterBy = filterBy.toLocaleLowerCase();
    this.filteredProjects = this.projects;
    return this.filteredProjects.filter(proj =>
      Object.keys(proj).some(
        k =>
          proj[k] != null &&
          proj[k]
            .toString()
            .toLowerCase()
            .includes(filterBy)
      )
    );
  }

  selectUser(firstName: string) {
    this.project.ManagerName = firstName;
  }

  filterUser(filterBy: string): IUser[] {
    filterBy = filterBy.toLocaleLowerCase();
    this.filteredUsers = this.users;
    return this.filteredUsers.filter(user =>
      Object.keys(user).some(
        k =>
          user[k] != null &&
          user[k]
            .toString()
            .toLowerCase()
            .includes(filterBy)
      )
    );
  }
}
