import { Component, OnInit } from "@angular/core";
import { UserService } from "../services/user.service";
import { IUser } from "../models/user";

@Component({
  selector: "app-user",
  templateUrl: "./user.component.html"
})
export class UserComponent implements OnInit {
  user: IUser = {
    Id: 0,
    FirstName: "",
    LastName: "",
    EmployeeId: null,
  };
  _userSearchFilter = "";

  users: IUser[] = [];
  filteredUsers: IUser[] = [];

  get userSearch(): string {
    return this._userSearchFilter;
  }
  set userSearch(value: string) {
    this._userSearchFilter = value;
    this.filteredUsers = this.userSearch
      ? this.filterUser(this.userSearch)
      : this.filteredUsers;
  }

  constructor(private userService: UserService) {}

  filterUser(filterBy: string): IUser[] {
    filterBy = filterBy.toLocaleLowerCase();
    this.filteredUsers = this.users;
    return this.filteredUsers.filter(user =>
      Object.keys(user).some(
        k =>
          user[k] != null &&
          user[k]
            .toString()
            .toLowerCase()
            .includes(filterBy)
      )
    );
  }

  ngOnInit() {
    this.userService.getUsers().subscribe(usrs => {
      this.users = usrs;
      this.filteredUsers = usrs;
    });
  }

  addUser() {
    this.userService.addUser(this.user).subscribe(res => console.log(res));
  }

  sort(sortby: string) {
    this.filteredUsers = this.filteredUsers.sort((a, b) =>
      a[sortby] > b[sortby] ? -1 : 1
    );
  }
}
