import { Component, OnInit } from '@angular/core';
import { ITask } from '../../models/task';
import { TaskService } from '../../services/task.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-task',
  templateUrl: './task-edit.component.html'
})

export class EditTaskComponent implements OnInit {
  task: ITask = {
    "Name": "",
    "ParentTask": "",
    "Priority": null,
    "StartDate": "",
    "EndDate": "",
    "Id": null,
    "ParentTaskId": null,
    "ProjectId": null,
    "ProjectName": "",
    "UserId": null,
    "UserName": ""
  };
  tasks: ITask[] = [];

  constructor(private route: ActivatedRoute, private taskService: TaskService, private router: Router) { }

  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getTasks();
      this.getTask(id);
    }
  }
  getTasks()
  {
    this.taskService.getTasks()
        .subscribe(tasks => {
          this.tasks = tasks 
        });  
  }  

  getTask(id: number) {
    this.taskService.getTask(id).subscribe(
      task => {
        this.task = task,
        this.task.StartDate = this.task.StartDate.substring(0,10);
        this.task.EndDate = this.task.EndDate.substring(0,10);
      });
  }

  updateTask() {
    this.taskService.updateTask(this.task);
    this.router.navigate(['/view-task']);

  }

}
