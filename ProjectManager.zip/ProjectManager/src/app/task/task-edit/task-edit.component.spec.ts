import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTaskComponent } from './task-edit.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { Router, convertToParamMap } from '@angular/router';
import { TaskService } from '../../services/task.service';
import { ITask } from '../../models/task';
import { NgForm } from '@angular/forms';
import { of } from 'rxjs';

describe('UpdateTaskComponent', () => {
  let component: EditTaskComponent;
  let mockRoute: any;
  let mockRouter: Router;
  let mockService: TaskService;
  let mockTasks: ITask[] = [];
  let taskForm: NgForm;

  beforeEach(() => {
    const task: ITask = {
      Name: "Task42",
      ParentTask: "parenttask11",
      Priority: 1,
      StartDate: "2019-09-12",
      EndDate: "2019-09-12",
      Id: 42,
      ParentTaskId: 11,
      ProjectId: null,
      ProjectName: "",
      UserId:1,
      UserName: "Batman"
    }
    
    mockTasks.push(task);

    mockService = jasmine.createSpyObj("TaskService", ["updateTask","getTask"]);   
    (mockService.getTask as jasmine.Spy).and.returnValue(of(task));

    mockRoute = {
      "snapshot": {
        "paramMap": convertToParamMap({ id: "42" })
      }
    };

    mockRouter = jasmine.createSpyObj("Router", ["navigate"]);
    (mockRouter.navigate as jasmine.Spy).and.returnValue(undefined);

    component = new EditTaskComponent(mockRoute, mockService, mockRouter);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  describe("ngOnInit", function () {
    it("should call getTask method when task Id is supplied", function () {
      // Arrange
      spyOn(component,"getTask");

      // Act
      component.ngOnInit();

      // Assert
      expect(component.getTask).toHaveBeenCalledWith(42);
    });
    
  describe("updateTask method", function () {
    it("should call updateTask method of taskService and navigate", function () {
      // Act
      component.updateTask();

      // Assert
      expect(mockService.updateTask).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalled();
    });
  })
})

});
