import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from '../../services/task.service';
import { ITask } from '../../models/task';


@Component({
  selector: "app-create-task",
  templateUrl: "./task-create.component.html"
})
export class CreateTaskComponent {
  task: ITask = {
    "Name": "",
    "ParentTask": "",
    "Priority": null,
    "StartDate": "",
    "EndDate": "",
    "Id": null,
    "ParentTaskId": null,
    "ProjectId": null,
    "ProjectName": "",
    "UserId": null,
    "UserName": ""
  };

  tasks: ITask[] = [];

  constructor(private router: Router, private taskService: TaskService) { 
    this.taskService.getTasks().subscribe(
      tasks => {
        this.tasks = tasks;
      });
  }

  addTask() {
    this.taskService.addTask(this.task).subscribe(
      result => {
        this.router.navigate(['/view-task']);
      });
  }
}
