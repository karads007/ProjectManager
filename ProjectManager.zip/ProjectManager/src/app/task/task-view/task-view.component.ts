import { Component, OnInit } from '@angular/core';
import { ITask } from '../../models/task';
import { TaskService } from '../../services/task.service';

@Component({
  selector: "app-view-task",
  templateUrl: "./task-view.component.html"
})
export class ViewTaskComponent implements OnInit {
  task: ITask = {
    "Id": null,
    "Name": "",
    "ParentTaskId": null,
    "ParentTask": "",
    "Priority": null,
    "StartDate": "",
    "EndDate": "",
    "ProjectId": null,
    "ProjectName": "",
    "UserId": null,
    "UserName": ""
  };
  _projectSearchFilter = "";
  
  filteredTasks: ITask[] = [];
  tasks: ITask[] = [];

  get projectSearch(): string {
    return this._projectSearchFilter;
  }
  set projectSearch(value: string) {
    this._projectSearchFilter = value;
    this.filteredTasks = this.projectSearch ? this.filterTask(this.projectSearch, "ProjectName") : this.tasks;
  }
 
  constructor(private taskService: TaskService) { }

  filterTask(filterBy: string, attributeName: any): ITask[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.filteredTasks.filter((task: any) =>
      task[attributeName].toString().toLocaleLowerCase().indexOf(filterBy) !== -1);
  }
  ngOnInit(): void {
    this.taskService.getTasks().subscribe(
      tasks => {
        this.tasks = tasks;
        this.filteredTasks = this.tasks;
      }
    );
  }

  sort(sortby: string) {
    this.filteredTasks = this.filteredTasks.sort((a, b) =>
      a[sortby] > b[sortby] ? -1 : 1
    );
  }
}
