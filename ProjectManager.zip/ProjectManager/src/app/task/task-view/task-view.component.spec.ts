import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewTaskComponent } from './task-view.component';
import { TaskService } from '../../services/task.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ITask } from '../../models/task';
import { of } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';

describe('ViewTaskComponent', () => {
  let component: ViewTaskComponent;
  let mockService: TaskService;
  let mockTasks: ITask[] = [];
  
  beforeEach(() => {
    const task: ITask = {
      Name: "Task",
      ParentTask: "parenttask",
      Priority: 1,
      StartDate: "2016-02-07",
      EndDate: "2019-09-25",
      Id: 2,
      ParentTaskId: 1,
      ProjectName: "Project 1",
      ProjectId: null,
      UserId:1,
      UserName: "Batman"
    }

    mockTasks.push(task);

    mockService = jasmine.createSpyObj("TaskService", ["getTasks"]);
    (mockService.getTasks as jasmine.Spy).and.returnValue(of(mockTasks));

    component = new ViewTaskComponent(mockService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  describe("ngOnInit", function () {
    it("should call getTasks of taskService", function () {
      // Act
      component.ngOnInit();

      // Assert
      expect(mockService.getTasks).toHaveBeenCalledTimes(1);
    });

    it("should set tasks and filtered tasks values", function () {
      // Act
      component.ngOnInit();

      // Assert
      expect(component.tasks).not.toBeUndefined();
      expect(component.filteredTasks).not.toBeUndefined();
    });
  })
  
  describe("Project Search setter", function () {
    it("should set filtered Project Search when tasks available", function () {
      // Arrange
       spyOn(component, "filterTask");

      // Act
      component.projectSearch = "Project 1";

      // Assert
      expect(component.filterTask).toHaveBeenCalled();
    });
  });
});
