export const environment = {
  production: true,
  baseUrl: "http://172.18.1.180:8088/api/"
};
