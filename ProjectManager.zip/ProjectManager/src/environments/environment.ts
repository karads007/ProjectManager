export const environment = {
  production: false,
  baseUrl: "api/"
};