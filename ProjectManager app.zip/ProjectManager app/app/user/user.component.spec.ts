import { TaskViewComponent } from './user.component';
import { TaskService } from '../services/task.service';
import { ITask } from '../models/task';
import { of } from 'rxjs';

describe('ViewTask Component', () => {
  let component: TaskViewComponent;
  let mockTestService: TaskService;
  let mockTasks: ITask[] = [];

  beforeEach(() => {
    const task: ITask = {
      id: 1100,
      name: "testTask1",
      priority: 1,
      parentTaskId: 1,
      parentTask: "parenttask1",
      startDate: "2019-03-10",
      endDate: "2019-03-10",
    }

    mockTasks.push(task);

    mockTestService = jasmine.createSpyObj("TaskService", ["getTasks"]);
    (mockTestService.getTasks as jasmine.Spy).and.returnValue(of(mockTasks));

    component = new TaskViewComponent(mockTestService);
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  describe("ngOnInit", function () {
    it("should call getTasks of taskService", function () {
      // Act
      component.ngOnInit();

      // Assert
      expect(mockTestService.getTasks).toHaveBeenCalledTimes(1);
    });

    it("should set tasks and filtered tasks values", function () {
      // Act
      component.ngOnInit();

      // Assert
      expect(component.tasks).not.toBeUndefined();
      expect(component.filteredTasks).not.toBeUndefined();
    });
  })

  describe("filterTask", function () {
    beforeEach(() => {
      const task1: ITask = {
        id: 1100,
        name: "testTask1",
        priority: 1,
        parentTaskId: 1,
        parentTask: "parenttask1",
        startDate: "2019-03-10",
        endDate: "2019-03-10",
      }

      const task2: ITask = {
        id: 1101,
        name: "testTask2",
        priority: 1,
        parentTaskId: 1100,
        parentTask: "parenttask1",
        startDate: "2019-03-10",
        endDate: "2019-03-10",
      }

      const task3: ITask = {
        id: 1103,
        name: "testTask3",
        priority: 1,
        parentTaskId: 1,
        parentTask: "parenttask1",
        startDate: "2019-03-10",
        endDate: "2019-03-10",
      }
  
      mockTasks.push(task1, task2, task3);
      component.filteredTasks = mockTasks;  
    });
    it("should filter by name", function () {
      // Act
      const result = component.filterTask("testTask2", "name");

      // Assert
      expect(result.length).toBeGreaterThan(0);
    });

    it("should filter by parentTask", function () {
      // Act
      const result = component.filterTask("parenttask1", "parentTask");

      // Assert
      expect(result.length).toBeGreaterThan(0);
    });

    it("should filter by priority", function () {
      // Act
      const result = component.filterTask("1", "priority");

      // Assert
      expect(result.length).toBeGreaterThan(0);
    });

    it("should filter by startDate", function () {
      // Act
      const result = component.filterTask("2019-03-10", "startDate");

      // Assert
      expect(result.length).toBeGreaterThan(0);
    });

    it("should filter by endDate", function () {
      // Act
      const result = component.filterTask("2019-03-10", "endDate");

      // Assert
      expect(result.length).toBeGreaterThan(0);
    });

  })

  describe("nameSearch getter", function () {
    it("should return name search text", function () {
      // Arrange
       component._nameSearchFilter = "task1000";
      // Act
      const result = component.nameSearch;

      // Assert
      expect(result).toEqual("task1000");
    });
  })

  describe("nameSearch setter", function () {
    it("should set nameSearch and filtered tasks when task text available", function () {
      // Arrange
       component._nameSearchFilter = "task1000";
       spyOn(component, "filterTask");

      // Act
      component.nameSearch = "task1001";

      // Assert
      expect(component._nameSearchFilter).toEqual("task1001");
      expect(component.filterTask).toHaveBeenCalled();
    });

    it("should set nameSearch and set all tasks with out filter when search text not available ", function () {
      // Arrange
       component._nameSearchFilter = undefined;
       spyOn(component, "filterTask");

      // Act
      component.nameSearch = undefined;

      // Assert
      expect(component.filterTask).not.toHaveBeenCalled();
    });
  })

  describe("parentTaskSearch getter", function () {
    it("should return parent task search filter text", function () {
      // Arrange
       component._parentTaskSearchFilter = "parentTask1";
      // Act
      const result = component.parentTaskSearch;

      // Assert
      expect(result).toEqual("parentTask1");
    });
  })

  describe("parentTaskSearch setter", function () {
    it("should set filtered parent tasks when tasks available", function () {
      // Arrange
       component._parentTaskSearchFilter = "parentTask1";
       spyOn(component, "filterTask");

      // Act
      component.parentTaskSearch = "parentTask2";

      // Assert
      expect(component.parentTaskSearch).toEqual("parentTask2");
      expect(component.filterTask).toHaveBeenCalled();
    });

    it("should set parentTaskSearch and set all parentTasks with out filter when search text not available ", function () {
      // Arrange
       component._parentTaskSearchFilter = undefined;
       spyOn(component, "filterTask");

      // Act
      component.parentTaskSearch = undefined;

      // Assert
      expect(component.filterTask).not.toHaveBeenCalled();
    });
  })

  describe("priorityToSearch getter", function () {
    it("should return priorityToSearch text", function () {
      // Arrange
       component._priorityToSearchFilter = "1";
      // Act
      const result = component.priorityToSearch;

      // Assert
      expect(result).toEqual("1");
    });
  })

  describe("priorityToSearch setter", function () {
    it("should set filtered priorityToSearch when tasks available", function () {
      // Arrange
       component._priorityToSearchFilter = "1";
       spyOn(component, "filterTask");

      // Act
      component.priorityToSearch = "2";

      // Assert
      expect(component.priorityToSearch).toEqual("2");
      expect(component.filterTask).toHaveBeenCalled();
    });

    it("should set parentTaskSearch and set all parentTasks with out filter when search text not available ", function () {
      // Arrange
       component._priorityToSearchFilter = undefined;
       spyOn(component, "filterTask");

      // Act
      component.parentTaskSearch = undefined;

      // Assert
      expect(component.filterTask).not.toHaveBeenCalled();
    });
  })

  describe("priorityFromSearch getter", function () {
    it("should return priorityToSearch text", function () {
      // Arrange
       component._priorityFromSearchFilter = "1";
      // Act
      const result = component.priorityFromSearch;

      // Assert
      expect(result).toEqual("1");
    });
  })

  describe("priorityFromSearch setter", function () {
    it("should set filtered priorityToSearch when tasks available", function () {
      // Arrange
       component._priorityFromSearchFilter = "1";
       spyOn(component, "filterTask");

      // Act
      component.priorityFromSearch = "2";

      // Assert
      expect(component.priorityFromSearch).toEqual("2");
      expect(component.filterTask).toHaveBeenCalled();
    });

    it("should set parentTaskSearch and set all parentTasks with out filter when search text not available ", function () {
      // Arrange
       component._priorityFromSearchFilter = undefined;
       spyOn(component, "filterTask");

      // Act
      component.priorityFromSearch = undefined;

      // Assert
      expect(component.filterTask).not.toHaveBeenCalled();
    });
  })
});
