import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TaskCreateComponent } from './task-create.component';
import { HttpClientModule } from '@angular/common/http';
import { TaskService } from '../services/task.service';
import { Router } from '@angular/router';
import { ITask } from '../models/task';
import { of } from 'rxjs';

describe('TaskCreateComponent', () => {
  let component: TaskCreateComponent;
  let mockTestService: TaskService;
  let mockRouter: Router;
  let mockTasks: ITask[] = [];
  
  beforeEach(() => {
    const task: ITask = {
      id: 1100,
      name: "testTask1",
      priority: 1,
      parentTaskId: 1,
      parentTask: "parenttask1",
      startDate: "2019-03-10",
      endDate: "2019-03-10",
    }

    mockTasks.push(task);
    const response: [] = [];

    mockTestService = jasmine.createSpyObj("TaskService", ["getTasks", "addTask"]);
    (mockTestService.getTasks as jasmine.Spy).and.returnValue(of(mockTasks));
    (mockTestService.addTask as jasmine.Spy).and.returnValue(of(response));

    mockRouter = jasmine.createSpyObj("Router", ["navigate"]);
    (mockRouter.navigate as jasmine.Spy).and.returnValue(undefined);

    component = new TaskCreateComponent(mockRouter, mockTestService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("ngOnInit", function () {
    it("should call getTasks of taskService", function () {
      // Act
      component.ngOnInit();

      // Assert
      expect(mockTestService.getTasks).toHaveBeenCalledTimes(1);
    });
    it("should set tasks", function () {
      // Act
      component.ngOnInit();

      // Assert
      expect(component.tasks).not.toBeUndefined();
    });
  });

  describe("createTask", function () {
    it("should call addTask and navigate", function () {
      // Act
      component.addTask();

      // Assert
      expect(mockTestService.addTask).toHaveBeenCalled();
      expect(mockRouter.navigate).toHaveBeenCalled();
    });
  });
});
