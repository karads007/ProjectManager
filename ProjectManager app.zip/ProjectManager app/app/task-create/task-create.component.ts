import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from '../services/task.service';
import { ITask } from '../models/task';


@Component({
  templateUrl: "./task-create.component.html"
})
export class TaskCreateComponent implements OnInit {
  task: ITask = {
    "id": null,
    "name": "",
    "priority": null,
    "parentTaskId": null,
    "parentTask": "",
    "startDate": "",
    "endDate": "",
  };  
  tasks: ITask[] = [];

  constructor(private router: Router, private taskService: TaskService) { }

  ngOnInit() {
    this.taskService.getTasks().subscribe(
      tasks => {
        this.tasks = tasks;
      });
  }
  
  addTask() {
    this.taskService.addTask(this.task).subscribe(
      result => {
        this.router.navigate(['/view-task']);
      });
  }
}
