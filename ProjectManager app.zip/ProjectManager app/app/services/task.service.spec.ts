import { TestBed } from '@angular/core/testing';

import { TaskService } from './task.service';
import { HttpClientModule, HttpClient, HttpHandler } from '@angular/common/http';
import { ITask } from '../models/task';
import { of } from 'rxjs';

describe('TaskService', () => {
  let service: TaskService;
  let mockHttpClient: HttpClient;
  let task:ITask;
  let tasks: ITask[] = [];
  beforeEach(() => {
    task = {
      id: 1101,
      name: "testTask2",
      priority: 1,
      parentTaskId: 1,
      parentTask: "parenttask1",
      startDate: "2019-03-10",
      endDate: "2019-03-10",
    }

    tasks.push(task);

    mockHttpClient = jasmine.createSpyObj("HttpClient", ["get", "post", "put", "delete"]);    
    (mockHttpClient.get as jasmine.Spy).and.returnValue(of(tasks));
    (mockHttpClient.post as jasmine.Spy).and.returnValue(undefined);
    (mockHttpClient.put as jasmine.Spy).and.returnValue(undefined);
    (mockHttpClient.delete as jasmine.Spy).and.returnValue(undefined);

    service = new TaskService(mockHttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe("addTask", function () {
    it("should call post of http client", function () {
      // Act
      service.addTask(task);

      // Assert
      expect(mockHttpClient.post).toHaveBeenCalled();
    });
  })
  
  describe("updateTask", function () {
    it("should call put of http client", function () {
      // Act
      service.updateTask(1, task);

      // Assert
      expect(mockHttpClient.put).toHaveBeenCalled();
    });
  })

  describe("getTasks", function () {
    it("should call get of http client", function () {
      // Act
      service.getTasks();

      // Assert
      expect(mockHttpClient.get).toHaveBeenCalled();
    });
  })

  describe("getTask", function () {
    it("should call get of http client", function () {
      // Act
      service.getTask(1);

      // Assert
      expect(mockHttpClient.get).toHaveBeenCalled();
    });
  })

  describe("deleteTask", function () {
    it("should call delete of http client", function () {
      // Act
      service.deleteTask(1);

      // Assert
      expect(mockHttpClient.delete).toHaveBeenCalled();
    });
  })
});
