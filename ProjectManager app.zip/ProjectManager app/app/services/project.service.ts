import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import { debug } from 'util';
import { environment } from 'src/environments/environment';
import { IProject } from '../models/project';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  private productUrl = environment.apiUrl + 'Projects';

  constructor(private http: HttpClient) { }

  getProjects(): Observable<IProject[]> {
    return this.http.get<IProject[]>(this.productUrl).pipe();
  }

  addProject(task: IProject): Observable<Object> {
    return this.http.post(this.productUrl, task);
  }

  updateProject(id: number, project: IProject): Observable<Object> {
    let url = this.productUrl + '/' + id;
    return this.http.put(url, project);
  }

  getProject(id: number): Observable<IProject | undefined> {
    return this.getProjects().pipe(
      map((users: IProject[]) => users.find(p => p.id === id))
    );
  }
}
