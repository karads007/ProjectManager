import { TestBed } from '@angular/core/testing';

import { ProjectService } from './project.service';
import { HttpClientModule, HttpClient, HttpHandler } from '@angular/common/http';
import { of } from 'rxjs';
import { IProject } from '../models/project';

describe('ProjectService', () => {
  let service: ProjectService;
  let mockHttpClient: HttpClient;
  let project:IProject;
  let projects: IProject[] = [];
  beforeEach(() => {
    project = {
      id: 1101,
      name: "project 1",
      priority: 10,
      projectManagerId: 1,
      startDate: "2019-03-10",
      endDate:"2019-03-10"
    };

    projects.push(project);

    mockHttpClient = jasmine.createSpyObj("HttpClient", ["get", "post", "put"]);    
    (mockHttpClient.get as jasmine.Spy).and.returnValue(of(projects));
    (mockHttpClient.post as jasmine.Spy).and.returnValue(undefined);
    (mockHttpClient.put as jasmine.Spy).and.returnValue(undefined);

    service = new ProjectService(mockHttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe("addProject", function () {
    it("should call post of http client", function () {
      // Act
      service.addProject(project);

      // Assert
      expect(mockHttpClient.post).toHaveBeenCalled();
    });
  })
  
  describe("updateProject", function () {
    it("should call put of http client", function () {
      // Act
      service.updateProject(1, project);

      // Assert
      expect(mockHttpClient.put).toHaveBeenCalled();
    });
  })

  describe("getProjects", function () {
    it("should call get of http client", function () {
      // Act
      service.getProjects();

      // Assert
      expect(mockHttpClient.get).toHaveBeenCalled();
    });
  })

  describe("getProject", function () {
    it("should call get of http client", function () {
      // Act
      service.getProject(1);

      // Assert
      expect(mockHttpClient.get).toHaveBeenCalled();
    });
  })
});
