import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ITask } from '../models/task';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import { debug } from 'util';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  private productUrl = environment.apiUrl + 'Tasks';

  constructor(private http: HttpClient) { }

  getTasks(): Observable<ITask[]> {
    return this.http.get<ITask[]>(this.productUrl).pipe();
  }

  addTask(task: ITask): Observable<Object> {
    return this.http.post(this.productUrl, task);
  }

  updateTask(id: number, task: ITask): Observable<Object> {
    let url = this.productUrl + '/' + id;
    return this.http.put(url, task);
  }

  getTask(id: number): Observable<ITask | undefined> {
    return this.getTasks().pipe(
      map((tasks: ITask[]) => tasks.find(p => p.id === id))
    );
  }

  deleteTask(id: number): Observable<object> {
    let url = this.productUrl + '/' + id;
    let headers: any = new Headers ({ 'Content-Type': 'application/json' });
    return this.http.delete(url, { headers: headers });
  }
}
