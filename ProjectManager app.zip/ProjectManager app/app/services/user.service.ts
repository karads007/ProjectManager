import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ITask } from '../models/task';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
import { debug } from 'util';
import { environment } from 'src/environments/environment';
import { IUser } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private productUrl = environment.apiUrl + 'Users';

  constructor(private http: HttpClient) { }

  getUsers(): Observable<IUser[]> {
    return this.http.get<IUser[]>(this.productUrl).pipe();
  }

  addUser(task: IUser): Observable<Object> {
    return this.http.post(this.productUrl, task);
  }

  updateUser(id: number, user: IUser): Observable<Object> {
    let url = this.productUrl + '/' + id;
    return this.http.put(url, user);
  }

  getUser(id: number): Observable<IUser | undefined> {
    return this.getUsers().pipe(
      map((users: IUser[]) => users.find(p => p.id === id))
    );
  }
}
