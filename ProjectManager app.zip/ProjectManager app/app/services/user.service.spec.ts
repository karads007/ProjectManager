import { TestBed } from '@angular/core/testing';

import { UserService } from './user.service';
import { HttpClientModule, HttpClient, HttpHandler } from '@angular/common/http';
import { of } from 'rxjs';
import { IUser } from '../models/user';

describe('UserService', () => {
  let service: UserService;
  let mockHttpClient: HttpClient;
  let user:IUser;
  let users: IUser[] = [];
  beforeEach(() => {
    user = {
      id: 1101,
      firstName: "Batman",
      lastName: "Robin",
      employeeId: 1001
    }

    users.push(user);

    mockHttpClient = jasmine.createSpyObj("HttpClient", ["get", "post", "put", "delete"]);    
    (mockHttpClient.get as jasmine.Spy).and.returnValue(of(users));
    (mockHttpClient.post as jasmine.Spy).and.returnValue(undefined);
    (mockHttpClient.put as jasmine.Spy).and.returnValue(undefined);

    service = new UserService(mockHttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe("addUser", function () {
    it("should call post of http client", function () {
      // Act
      service.addUser(user);

      // Assert
      expect(mockHttpClient.post).toHaveBeenCalled();
    });
  })
  
  describe("updateUser", function () {
    it("should call put of http client", function () {
      // Act
      service.updateUser(1, user);

      // Assert
      expect(mockHttpClient.put).toHaveBeenCalled();
    });
  })

  describe("getUsers", function () {
    it("should call get of http client", function () {
      // Act
      service.getUsers();

      // Assert
      expect(mockHttpClient.get).toHaveBeenCalled();
    });
  })

  describe("getUser", function () {
    it("should call get of http client", function () {
      // Act
      service.getUser(1);

      // Assert
      expect(mockHttpClient.get).toHaveBeenCalled();
    });
  })
});
