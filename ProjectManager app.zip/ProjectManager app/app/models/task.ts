export interface ITask {
    id: number;
    name: string;
    priority: number;
    parentTaskId: number;
    parentTask: string;
    startDate: string;  
    endDate: string;   
}