export interface IProject {
    id: number;
    name: string;
    priority: number;
    projectManagerId: number;
    startDate: string;
    endDate: string;
}