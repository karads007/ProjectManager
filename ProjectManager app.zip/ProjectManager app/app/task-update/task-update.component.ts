import { Component, OnInit } from '@angular/core';
import { ITask } from '../models/task';
import { TaskService } from '../services/task.service';
import { ActivatedRoute, Router } from '@angular/router';
import { pipe } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  templateUrl: './task-update.component.html'
})

export class TaskUpdateComponent implements OnInit {
  task : ITask  = {
    "id": null,
    "name": "",
    "priority": null,
    "parentTaskId": null,
    "parentTask": "",
    "startDate": "",
    "endDate": "",
  };  
  tasks: ITask[] = [];

  constructor(
    private route: ActivatedRoute, 
    private taskService: TaskService, 
    private router: Router) { }

  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id');
    if (param) {
      const id = +param;
      this.getTasks(id);
      this.getTask(id);
    }
  }

  getTasks(id: number)
  {
    this.taskService.getTasks()
        .pipe(map(tasks => { 
          return tasks.filter(t => t.id !== id); }))
        .subscribe(tasks => {
          this.tasks = tasks 
        });  
  }  
  getTask(id: number) {
    this.taskService.getTask(id).subscribe(
      task => this.task = task);
  }

  updateTask(id: number) {
    this.taskService.updateTask(id, this.task).subscribe(
      result => {
        this.router.navigate(['/view-task']);
      });
  }

}
