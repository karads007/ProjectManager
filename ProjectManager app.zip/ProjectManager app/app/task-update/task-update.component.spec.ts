import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskUpdateComponent } from './task-update.component';
import { HttpClientModule } from '@angular/common/http';
import { TaskService } from '../services/task.service';
import { ITask } from '../models/task';
import { Router, convertToParamMap } from '@angular/router';
import { of } from 'rxjs';

describe('TaskUpdateComponent', () => {
  let component: TaskUpdateComponent;
  let mockTaskService: TaskService;
  let mockTasks: ITask[] = [];
  let mockRoute: any;
  let mockRouter: Router;

  beforeEach(() => {
    const task: ITask = {
      id: 1100,
      name: "testTask1",
      priority: 1,
      parentTaskId: 1,
      parentTask: "parenttask1",
      startDate: "2019-03-10",
      endDate: "2019-03-10",
    }

    mockTasks.push(task);
    const response: [] = [];
    mockTaskService = jasmine.createSpyObj("TaskService", ["getTasks", "getTask", "updateTask"]);
    (mockTaskService.getTasks as jasmine.Spy).and.returnValue(of(mockTasks));
    (mockTaskService.updateTask as jasmine.Spy).and.returnValue(of(response));

    mockRoute = {
      "snapshot": {
        "paramMap": convertToParamMap({ id: "1100" })
      }
    };

    mockRouter = jasmine.createSpyObj("Router", ["navigate"]);
    (mockRouter.navigate as jasmine.Spy).and.returnValue(undefined);

    component = new TaskUpdateComponent(mockRoute, mockTaskService, mockRouter);
  });
    
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe("ngOnInit", function () {
    it("should call getTasks and getTask of taskService", function () {
      // Arrange
      spyOn(component, "getTask");
      spyOn(component, "getTasks");

      // Act
      component.ngOnInit();

      // Assert
      expect(component.getTasks).toHaveBeenCalledTimes(1);
      expect(component.getTask).toHaveBeenCalledWith(1100);
    });

    it("should not call getTasks and getTask if param not passed", function () {
      // Arrange
      mockRoute = {
        "snapshot": {
          "paramMap": convertToParamMap({ })
        }
      };
      spyOn(component, "getTask");
      spyOn(component, "getTasks");

      // Act
      component.ngOnInit();

      // Assert
      expect(component.getTasks).not.toHaveBeenCalled;
      expect(component.getTask).not.toHaveBeenCalled;
    });
  });
});
