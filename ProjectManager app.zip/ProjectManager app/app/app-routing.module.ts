import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TaskCreateComponent } from './task-create/task-create.component';
import { TaskViewComponent } from './task-view/task-view.component';
import { TaskUpdateComponent } from './task-update/task-update.component';

const routes: Routes = [
  { path:"", component: TaskViewComponent },
  { path:"view-task", component: TaskViewComponent },
  { path:"update-task", component: TaskUpdateComponent },
  { path:"create-task", component: TaskCreateComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation:'reload' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
